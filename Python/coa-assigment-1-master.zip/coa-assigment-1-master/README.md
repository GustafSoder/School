# CoA Assigment 1

Your task in this assignment is to write an assembler for a subset of the MIPS instruction set. The program shall read one source code file with mnemonic instructions and produce two files, one with encoded instructions in hexadecimal format, and one