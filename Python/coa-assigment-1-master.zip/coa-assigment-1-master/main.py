#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Authors: Alban Gashi, Arian Moeini, Gustaf Söderlund


import sys
import re
from Instruction import Instruction
from Register import Register
from textwrap import wrap

"""
positive_int_to_hex(value)
    function that reformats integer to hexadecimal string value.
    
@:value: input integer    
@:return string
"""


def positive_int_to_hex(value):
    k = '{0:16X}'.format(value)
    k = k.lstrip(' ')

    return k


"""
int_to_16bit_binary(value)
    function that reformats integer to a 16-bit binary string.
    
@:value: input integer    
@:return string
"""


def int_to_16bit_binary(value):
    k = '{0:016b}'.format(value)
    k = k.lstrip(' ')

    return k


"""
int_to_28bit_binary(value)
    function that reformats integer to a 28-bit binary string.
    
@:value: input integer    
@:return string
"""


def int_to_28bit_binary(value):
    k = '{0:028b}'.format(value)
    k = k.lstrip(' ')

    return k


"""
find_two_complement(str)
    function that reformats a binary input string
    to its two complement.
    
@:value: binary input string    
@:return complement string
"""


def find_two_complement(str):
    n = len(str)
    for i in range(n - 1, -1, -1):
        if str[i] == '1':
            break

    # If there exists no '1' at the starting of string
    if i == -1:
        return '1' + str

    for k in range(i - 1, -1, -1):  # Continue traversal

        if str[k] == '1':  # flip the values
            str = list(str)
            str[k] = '0'
            str = ''.join(str)
        else:
            str = list(str)
            str[k] = '1'
            str = ''.join(str)

    return str  # return the modified string


"""
get_hex_conversion(encoded_instruction)
    Splits the 32 bit encoded_instruction instruction into blocks of 4 
    and converts each block to hexadecimal.
    
@:value: encoded_instruction string    
@:return string representing the 32-bit binary input in hexadecimal
"""


def get_hex_conversion(encoded_instruction):
    split_bit = wrap(encoded_instruction, 4)

    result = "0x"
    for item in split_bit:
        temp = int(item, 2)
        temp = positive_int_to_hex(temp)
        result += temp
    return result


"""
create_symbol_dict(array)
    Creates a dictionary containing each input row as key and 
    their memory location as value.
@:value: array containing each input row    
@:return dictionary
"""


def create_symbol_dict(array):
    data = dict()
    ind = int(0)
    for i in array:
        if (i[0] != "") or (i[1] != ""):

            if i[0] != "":
                i[0] = re.sub(r":", "", i[0])
                data[i[0]] = "{0:08x}".format(ind)
            else:
                data[str(i)] = "{0:08x}".format(ind)
            if i[1] != "":
                ind = ind + 4

    return data


"""
get_input()
    Iterates through each line of the input file and uses regex to 
    separate the necessary values into a array of strings. 
@:return Array of strings 
"""


def get_input():
    return_array = []
    textfile = input("Enter the textfile without .txt: ")

    with open(textfile + ".txt", 'r') as row:
        for i, row in enumerate(row.readlines()):
            if len(row.split()) != 0:
                if not row.startswith("#"):
                    row = str(row.split("\n"))
                    list = re.sub(r"[\[{,})\]']", "", row)
                    list = list.replace('\\t', " ")
                    array = re.split("[\s,(]+", list, maxsplit=5)
                    return_array.append(array)

    return return_array


def main():
    mips_list = get_input()
    ind = 0
    for array in mips_list:

        array_dic = create_symbol_dict(mips_list)  # Creating dictionary
        result = ""
        try:
            value1 = Instruction(array[1])  # Set value 1 as Instruction
            # check Instruction type
            if value1.type == "R":
                value2 = Register(array[2])
                result = instruction_type_r(array, value1, value2)
            elif value1.type == "I":
                value2 = Register(array[2])
                result = instruction_type_i(array, value1, value2, array_dic)
            elif value1.type == "J":
                value2 = Register(array[2])
                result = instruction_type_j(value1, value2, array_dic)
            elif value1.type == "0":
                result = "0x00000000"

        except KeyError:
            if array[0] not in array_dic.keys():
                result = "Instruction is unknown."

        write_to_file(result, array, ind)   #write the result to the file
        write_encoded_result(result)
        ind = ind + 4  #add 4 to the index. 
    write_symbol_to_file(array_dic) #write the symboltable to the output file.


def instruction_type_r(array, value1, value2):
    op = "000000"
    funct = value1.hexadecimalname
    shamt = "00000"
    rd = value2.hexadecimalregister

    if value1.myname == "jr":  # Special case if instruction is "jr"
        jr_zeros = "000000000000000"
        encoded_instruction = "".join((op, rd, jr_zeros, funct))
        result = get_hex_conversion(encoded_instruction)
        return result

    value3 = Register(array[3])
    rs = value3.hexadecimalregister

    if value1.myname == "sll":  # Special case if instruction is "sll"
        temp = int(array[4])
        shamt = '{0:05b}'.format(temp)
        rs = "00000"
        shamt = shamt.lstrip(' ')
        rt = value3.hexadecimalregister
    else:
        value4 = Register(array[4])
        rt = value4.hexadecimalregister

    if rd is not None:  # Check if input register rd is set to something
        encoded_instruction = "".join((op, rs, rt, rd, shamt, funct))  # Get the 32bit instruction code
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"


def instruction_type_i(array, value1, value2, array_dic):
    op = value1.hexadecimalname

    if value1.myname == "lw" or value1.myname == "sw":  # Special case if instruction is "lw" or "sw"
        imm = int(array[3])
        imm = int_to_16bit_binary(imm)
        rs = Register(array[4]).hexadecimalregister
        rt = value2.hexadecimalregister
    elif value1.myname == "addi":  # Special case if instruction is "addi"
        imm = int(array[4])
        if imm < 0:  # Check if input constant is negative
            imm = abs(imm)
            imm = int_to_16bit_binary(imm)
            imm = find_two_complement(imm)
        else:
            imm = int_to_16bit_binary(imm)
        rs = Register(array[3]).hexadecimalregister
        rt = value2.hexadecimalregister
    elif value1.myname == "beq":
        try:
            label_value = array_dic[str(array[4])]  # We get PC_start from dictionary in hex
        except KeyError:
            return "unknown jump target"
        # Calculate pc_start = (pc_b+4) + 4*n
        pc_start = int(label_value, 16)  # Convert value to an integer
        pc_b = int(array_dic[str(array)], 16) + 4  # Get our current memory address and convert to in value
        n = (pc_start - pc_b) / 4  # Calculated n value
        imm = abs(n)
        imm = int_to_16bit_binary(int(imm))
        imm = find_two_complement(imm)

        rs = value2.hexadecimalregister
        rt = Register(array[3]).hexadecimalregister

    if rt is not None:

        encoded_instruction = "".join((op, rs, rt, imm))
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"


def instruction_type_j(value1, value2, array_dic):
    op = value1.hexadecimalname
    try:
        label_value = array_dic[str(value2.myname)]
    except KeyError:
        return "unknown jump target"

    address = int_to_28bit_binary(int(label_value, 16))
    address_26bit = address[:-2]  # Remove the two last bits of the 28-bit binary
    if op is not None:

        encoded_instruction = "".join((op, address_26bit))
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"   

"""
    write_symbol_to_file()
    This function has the responsibility to write the symbol table to the outputfile. 
    Search for the lable keys in the dictionary and add them to the key_list. 
    When all the keys are located. print the key and it's corresponding value aka memory adress. 
    
    @array_dic: Is the dictionary containing each label and instruction memory adress. 
"""
def write_symbol_to_file(array_dic):
    key_list = []

    for key in array_dic:
        if not key.startswith("["):
            key_list.append(key)

    outputfile = open("result.txt", 'a')
    outputfile.write("\n\nSYMBOL TABLE\n")

    for i in key_list:
        outputfile.write('%s: ' % i)
        outputfile.write('0x%s ' % array_dic.get(str(i)))
        outputfile.write('\n')
    outputfile.close()


"""
write_to_file()
This function has the responsibillity to write the results from the encoding to 
a file. 

@param result:  This parameter is the result from encoding.
@param array:   This array contains the infromation from the input file. 
                Instructions, register, labels etc. 
@ind:           this parameter contain the memory location of the instruction/label. 
"""
def write_to_file(result, array, ind):
    ind = "0x{0:08x}".format(ind)
    outputfile = open("result.txt", 'a')

    # print memory location
    outputfile.write('%s\t' % ind)

    # print error if any. 
    if result == "Wrong input register" or result == "unknown jump target" or result == "unknown branch":
        outputfile.write('\t\t\t\t\t %s' % result)
    else:  # else print the result. aka encoded text and the instructions
        outputfile.write('%s\t' % result)
        # instruction and register.
        if len(result) == 0:
            outputfile.write('\t\t')
        # if the first location in the array contains a label. 
        #save the label to temp. Add ':\t' to make the print look pretty.
        if array[0] != "":
            temp = array[0]
            array[0] = array[0] + ':\t'

        else: #Add two tabs to make the file look pretty. 
            outputfile.write('\t\t')

        #get length of the array. 
        n = len(array)
        for i, item in enumerate(array):
            #if the item contain anything except "" print it to the file. 
            if item != "":
                outputfile.write(' %s' % item)
            #except the two first and the two last prints should have a comma after. 
            if 1 < i < n - 2:
                outputfile.write(',')
        #Return the saved temp to the array and add only ':'
        if array[0] != "":
            array[0] = temp + ':'

    outputfile.write('\n')
    outputfile.close() #close file. 
    return

def write_encoded_result(result):
    outputfile = open("instruction.txt", 'a')
    if result != "":
        outputfile.write('%s' % result) 
        outputfile.write('\n')
    outputfile.close() #close file.



if __name__ == '__main__':
    main()
