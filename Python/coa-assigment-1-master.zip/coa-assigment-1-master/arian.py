# Authors: Alban Gashi, Arian Moeini, Gustaf Söderlund

import sys
from Instruction import Instruction
from Register import Register
from textwrap import wrap


def take_input():
    textFil = input("Enter the textfile without .txt: ")

    with open(textFil + ".txt", 'r') as row:
        contents = row.read()
    return contents


def positive_int_to_hexa(value):
    k = '{0:16X}'.format(value)
    k = k.lstrip(' ')

    if value < 16:
        k = "0" + k
    return k


def int_to_binary(value):
    k = "{0:b}".format(value)
    return k


def negative_int_to_hexa(value):
    negative_int = 256 + value
    return positive_int_to_hexa(negative_int)


def num_to_bin(num):
    if num < 0:
        num = (1 << 8) + num
    base = bin(num)[2:]
    padding_size = 8 - len(base)
    return '0' * padding_size + base


def main():
    array = ["fact:", "addi", "$s0", "$t0", "$t1"]

    try:
        value1 = Instruction(array[1])

        value2 = Register(array[2])
        value3 = Register(array[3])

        if value3.hexadecimalregister is None:
            value3 = int(array[3])
            if value3 < 0:
                hex3 = negative_int_to_hexa(value3)
            else:
                hex3 = positive_int_to_hexa(value3)
        else:
            hex3 = positive_int_to_hexa(value3.hexadecimalregister)

        value4 = Register(array[4])

        if value4.hexadecimalregister is None:
            value4 = int(array[4])
            if value4 < 0:
                hex4 = negative_int_to_hexa(value4)
                hex3 = positive_int_to_hexa((~value3.hexadecimalregister & 0xFF))
            else:
                hex4 = positive_int_to_hexa(value4)
        else:
            hex4 = positive_int_to_hexa(value4.hexadecimalregister)

        if value1.hexadecimalname is None:
            print("ERROR: Wrong instruction ")
        else:
            bit_shifted = (value1.hexadecimalname << 2)
            bit_shifted8bit = "{0:{fill}8b}".format(bit_shifted, fill='0')
            print(bit_shifted8bit)
            split_bit = wrap(bit_shifted8bit, 4)
            upper = int(split_bit[0], 2)
            lower = int(split_bit[1], 2)

            print(upper)
            print(lower)
            print(positive_int_to_hexa(value2.hexadecimalregister))
            print(hex3)
            print(hex4)

            encoded_instruction = "0x" + "".join(
                (str(upper), str(lower), positive_int_to_hexa(value2.hexadecimalregister), hex3, hex4))
            print(encoded_instruction)

    except KeyError:
        print("Instruction is unknown.")


# c = Instruction("addi")
# print(int_to_binary(c.hexadecimalname))


"""
Algoritm:
1).Ladda in array med alla värden   
2).Loopar igenom en array
3).få ut operander
4).kolla om värdena är register eller int
5).Få ut 8 bit värde
4).kolla ifall värdet är negativt, skriv ut komplement
    4.1) annars skriv ut vanlogt
5)
"""

