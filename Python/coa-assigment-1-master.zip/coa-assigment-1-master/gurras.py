# Authors: Alban Gashi, Arian Moeini, Gustaf Söderlund

import sys
import re
from Instruction import Instruction
from Register import Register
from textwrap import wrap


def take_input():
    textFil = input("Enter the textfile without .txt: ")

    with open(textFil + ".txt", 'r') as row:
        contents = row.read()
    return contents


def positive_int_to_hex(value):
    k = '{0:16X}'.format(value)
    k = k.lstrip(' ')

    return k


def int_to_16bit_binary(value):
    k = '{0:016b}'.format(value)
    k = k.lstrip(' ')

    return k


def int_to_28bit_binary(value):
    k = '{0:028b}'.format(value)
    k = k.lstrip(' ')

    return k


def find_two_complement(str):
    n = len(str)
    for i in range(n - 1, -1, -1):
        if str[i] == '1':
            break

    # If there exists no '1' concatenate 1
    # at the starting of string
    if i == -1:
        return '1' + str

    # Continue traversal after the
    # position of first '1'

    for k in range(i - 1, -1, -1):

        # Just flip the values
        if str[k] == '1':
            str = list(str)
            str[k] = '0'
            str = ''.join(str)
        else:
            str = list(str)
            str[k] = '1'
            str = ''.join(str)

    # return the modified string
    return str


def get_hex_conversion(encoded_instruction):
    split_bit = wrap(encoded_instruction, 4)

    result = "0x"
    for item in split_bit:
        temp = int(item, 2)
        temp = positive_int_to_hex(temp)
        result += temp
    return result


def create_symbol_dict(array):
    data = dict()
    ind = int(0)
    for i in array:
        if (i[0] != "") or (i[1] != ""):

            if i[0] != "":
                i[0] = re.sub(r":", "", i[0])
                data[i[0]] = "{0:08x}".format(ind)
            else:
                data[str(i)] = "{0:08x}".format(ind)
            if i[1] != "":
                ind = ind + 4

    return data


def get_input():
    return_array = []
    textfile = input("Enter the textfile without .txt: ")

    with open(textfile + ".txt", 'r') as row:
        for i, row in enumerate(row.readlines()):
            if len(row.split()) != 0:
                if not row.startswith("#"):
                    row = str(row.split("\n"))
                    list = re.sub(r"[\[{})\]']", "", row)
                    list = list.replace('\\t', " ")
                    array = re.split("[\s,(]+", list, maxsplit=5)
                    return_array.append(array)

    return return_array


def main():
    mips_list = get_input()
    ind = 0
    for array in mips_list:

        array_dic = create_symbol_dict(mips_list)
        result = ""
        try:
            value1 = Instruction(array[1])

            if value1.type == "R":
                value2 = Register(array[2])
                result = instruction_type_r(array, value1, value2)
                print(result)
            elif value1.type == "I":
                value2 = Register(array[2])
                result = instruction_type_i(array, value1, value2, array_dic)
                print(result)
            elif value1.type == "J":
                value2 = Register(array[2])
                result = instruction_type_j(value1, value2, array_dic)
                print(result)
            elif value1.type == "0":
                result = "0x00000000"
                print(result)
            else:
                print("ERROR")

        except KeyError:
            if array[0] not in array_dic.keys():
                result = "Instruction is unknown."
        write_to_file(result, array, ind)
        ind = ind +4
    write_symbol_to_file(array_dic)

def write_symbol_to_file(array_dic):
    key_list = []

    for key in array_dic:
        if not key.startswith("["):
            key_list.append(key) 

   

    outputfile = open("output.txt", 'a')
    outputfile.write("\n\nSYMBOL TABLE\n")
    for i in key_list:
        outputfile.write('%s: ' % i)
    

        outputfile.write('%s ' % array_dic.get(str(i)))
        outputfile.write('\n')
    outputfile.close()

def write_to_file(result, array, ind):
    ind = "0x{0:08x}".format(ind)
    outputfile = open("output.txt", 'a')

    #print memory location
    outputfile.write('%s\t' %  ind)

    # print error if any. 
    if result == "Wrong input register" or result == "unknown jump target" or result == "unknown branch":
        outputfile.write('\t\t\t\t\t %s' % result)
    else: #else print the result. aka encoded text and the instructions 
        outputfile.write('%s\t' % result)
        #instruction and register.
        if len(result) == 0:
            outputfile.write('\t\t')

    
     
        if array[0] != "":
            array[0] = array[0] + ':\t'
        else:
            outputfile.write('\t\t')

        n = len(array)
          
        for i, item in enumerate(array):
            if item != "":
                outputfile.write(' %s' % item)

            if i>1 and i<n-2:
                outputfile.write(',')
            
    outputfile.write('\n')
    outputfile.close() 



def instruction_type_r(array, value1, value2):
    op = "000000"
    funct = value1.hexadecimalname
    shamt = "00000"
    rd = value2.hexadecimalregister

    if value1.myname == "jr":
        jr_zeros = "000000000000000"
        encoded_instruction = "".join((op, rd, jr_zeros, funct))
        result = get_hex_conversion(encoded_instruction)
        return result

    value3 = Register(array[3])
    rs = value3.hexadecimalregister

    if value1.myname == "sll":
        temp = int(array[4])
        shamt = '{0:05b}'.format(temp)
        rs = "00000"
        rt = value3.hexadecimalregister
        shamt = shamt.lstrip(' ')
        rt = value3.hexadecimalregister
    else:
        value4 = Register(array[4])
        rt = value4.hexadecimalregister

    if rd is not None:

        encoded_instruction = "".join((op, rs, rt, rd, shamt, funct))
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"


def instruction_type_i(array, value1, value2, array_dic):
    op = value1.hexadecimalname

    if value1.myname == "lw" or value1.myname == "sw":
        imm = int(array[3])
        imm = int_to_16bit_binary(imm)
        rs = Register(array[4]).hexadecimalregister
        rt = value2.hexadecimalregister
    elif value1.myname == "addi":
        imm = int(array[4])
        if imm < 0:
            imm = abs(imm)
            imm = int_to_16bit_binary(imm)
            imm = find_two_complement(imm)
        else:
            imm = int_to_16bit_binary(imm)
        rs = Register(array[3]).hexadecimalregister
        rt = value2.hexadecimalregister
    elif value1.myname == "beq":
        try:
            label_value = array_dic[str(array[4])]  # We get PCstart from dictionairy in hex
        except KeyError:
            return "unknown branch"
        # Calulate pc_start = (pc_b+4) + 4*n
        pc_start = int(label_value, 16)  # Convert value to an integer
        pc_b = int(array_dic[str(array)], 16) + 4  # Get our current memory adress and convert to in value
        n = (pc_start - pc_b) / 4  # Calculated n value
        imm = abs(n)
        imm = int_to_16bit_binary(int(imm))
        imm = find_two_complement(imm)

        rs = value2.hexadecimalregister
        rt = Register(array[3]).hexadecimalregister

    if rt is not None:

        encoded_instruction = "".join((op, rs, rt, imm))
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"


def instruction_type_j(value1, value2, array_dic):
    op = value1.hexadecimalname
    try:
        label_value = array_dic[str(value2.myname)]
    except KeyError:
        return "unknown jump target"

    adress = int_to_28bit_binary(int(label_value, 16))
    adress = adress[:-2]
    if op is not None:

        encoded_instruction = "".join((op, adress))
        result = get_hex_conversion(encoded_instruction)
        return result
    else:
        return "Wrong input register"


if __name__ == '__main__':
    main()
