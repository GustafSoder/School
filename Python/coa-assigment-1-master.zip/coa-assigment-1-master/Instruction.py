from Register import Register


class Instruction:

    def __init__(self, myname=str()):
        self.myname = myname
        self.hexadecimalname = self.thisdict[self.myname][0]
        self.type = self.thisdict[self.myname][1]

    thisdict = {
        "addi": ("001000", "I"),
        "add": ("100000", "R"),
        "sub": ("100010", "R"),
        "and": ("100100", "R"),
        "or": ("100101", "R"),
        "nor": ("100111", "R"),
        "slt": ("101010", "R"),
        "lw": ("100011", "I"),
        "sw": ("101011", "I"),
        "beq": ("000100", "I"),
        "sll": ("000000", "R"),
        "j": ("000010", "J"),
        "jr": ("001000", "R"),
        "nop": ("000000", "0"),
    }

    def __str__(self):
        return "Name is: " + self.myname + ",My hexadecimal value is: " + str(self.hexadecimalname) \
               + ",Type: " + str(self.type)
