# Authors: Alban Gashi

import sys
import re


def tempfunc():
    """Just temporary func replacer for something else"""
    print("Do something")


def take_input():
    """Takes an input .txt file and removes all comments from it"""
    textFil = input("Enter the textfile without .txt: ")

    with open(textFil + ".txt", 'r') as row:
        contents = row.read()
        print("hej")
        print(contents)
    #  mips_list = sort_out_comments(contents)

    return contents

def get_input():
    array = []
    textFil = input("Enter the textfile without .txt: ")

    with open(textFil+".txt", 'r') as row:

        for i, row in enumerate(row.readlines()):
            row = row.split("\n")
            array.append(str(row))

    return array

def sort_out_comments(row):
    """
    sort_out_comments Takes the parameter row and removes comments from it.

    :param row: The row to be sorted
    :return: Sorts out the row for MIPS instructions and returns it if exists.
    """
    # Check for empty row
    # Does not work if row doesnt have \n,\t,\s or blankspace, PROB works with empty row
    empty_row = re.search("^$|^\s.*$", row)
    if empty_row:
        pass

    # Removes everything after a comment
    comment_split = re.split("#.*", row)

    # Everything before the #
    before_comment = comment_split[0]
    if not before_comment:
        pass

    return before_comment


def sort_labels(mips_list):
    """
    sort_labels takes out the labels and returns them in a list.

    :param row: None if no labels, list if labels
    """
    # Split out labels that have whitespace in front of it
    # necessary??
    # check1 = re.split("^\s.+:", mips_list, re.MULTILINE)
    # if not check1[0]:
    #     pass

    # Only takes out labels
    # ^\S+: Matches any that has no whitespace in front of it, and then label
    # check2 = re.search("^\S+:", mips_list, re.MULTILINE)
    # #If no labels, return None
    # if not check2:
    #     pass

    # Takes out all the labels in list and gives them own places
    labels_list = re.findall("^\S+:.*", mips_list)
    return labels_list


def sort_instructions(labels_list):
    # finds the instructions,
    # Bound by a whitespace before,bound by word, after any character except \n, and after only chars, atleast 1 (which will take away numbers)
    # ^\s+\w+, om man vill kolla att string ska börja med whitespace och sedan fortsätter
    instructions_list = re.split("\s\b.\w+", labels_list)

    pass


def sort_parameters(instructions_list):
    # [^\s\b.\w+] finds all special characters
    # Find the parameters, bound by starting with atleast 1$ and atleast 1character and ends with a ,
    # Add a * after , to find all references
    parameters_list = re.split("\$+\w+,", instructions_list)

    pass


"""
Algoritm:
1). Kolla om det är label eller instruction
1a). Label gå till Steg 2). 
1b). Om instruction gå till Steg 3).

2). Gå igenom flera rader tills nästa label och lägg dem i en lista.
2a). Om nästa rad börjar med label, då är labels tillhöranda varandra.
2b). Sortera även ut varje instruction samt parametrarna och lägg till i följande positionerna i listan 
    (eventuellt göra instructions till dubbelarray, då en label kan ha massvis med rader av instructions).
2c). Klar, gå till Steg 4).

3). Sortera ut instructionen med namn i första position, och parametrarna i de följande positionerna så de kan läsas av lätt.
3a). Klar, Gå till Steg 4).

4). Gör encoder funktion på listan mottagen
5). Skriv ut till den nya filen den encodade listan

????
- Ska man namnge varje lista i deras första position så encoder vet om det är LISTA eller INSTRUCTION
"""


def sort_mipslist(mips_list):
    """
    Goes throught the mips_list row for row and encodes it.

    :param mips_list: The list containing the MIPS instructions.
    """

    # Keep check of what the last label was
    last_label = False

    for row in mips_list:
        # For second label to appear
        label2 = False

        # Only takes out labels
        # ^\S+: Matches any that has no whitespace in front of it, and then label
        label = re.search("^\S+:", mips_list, re.MULTILINE)

        # To compare labels until next label
        if label:
            # Checks that the last_label isn't True, then not time to encode
            if not last_label and label2:
                # encode the current list
                tempfunc(labels_list)
                # clear the list
                labels_list.clear()
            else:
                last_label = True
                label2 = True
        else:
            last_label = False

        # If labels take all instructions until next label or EOF
        if label2:
            labels_list = sort_labels(row)
            label_instructions = sort_instructions(row)
            # Continue for next label
            continue
        else:
            # If no labels were found only take instructions till next label or EOF
            ist_list = sort_instructions()
            # depending on which we have, encode it, this case tempfunc = encode(list)
            tempfunc(ist_list)

    print("Encoding done!")


def main():
    mips_list = get_input()

    for row in mips_list:
        list = re.sub(r"[\[{})\]']", "", row)
        labels_list = re.split("[\s,(]+", list, maxsplit = 5)
        print(labels_list)

    #labels_list = sort_labels(mips_list)


main()
